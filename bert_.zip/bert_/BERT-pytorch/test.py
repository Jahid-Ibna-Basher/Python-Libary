import unittest
from bert_pytorch import BERT


class BERTVocabTestCase(unittest.TestCase):
    pass
